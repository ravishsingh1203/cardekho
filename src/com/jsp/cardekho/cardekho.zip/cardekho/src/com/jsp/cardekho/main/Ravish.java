package com.jsp.cardekho.main;

public class Ravish 
{
	public static void main(String[] args) {
		System.out.println("Hello");
	}

}
